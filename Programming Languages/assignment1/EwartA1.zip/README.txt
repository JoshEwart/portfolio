README:

To run InsertionSort in C++, take the InsertionSort.cpp file and upload to pegasus,
one there, go to the directory where the file is saved, type in:
g++ InsertionSort.cpp
this will create an "a.out" executable file. run this by typing in:
./a.out
This will generate an array that is sorted with Insertion sort in C++.

To run InsertionSort in Java, take InsertionSort.java and upload to pegasus.
Log into pegasus, and go to the directory you uploaded the file into, and type:
javac InsertionSort.java
This will create a "Insertionsort.class" file, which can be ran using:
java InsertionSort
This will generate an array that is sorted with Insertion sort in java.
